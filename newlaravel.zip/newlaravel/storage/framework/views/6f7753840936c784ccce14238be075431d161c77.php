<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">User List</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          Listing All 
                        </div>
             <span class="msg">             

                </span>
            <div id="showMsg"></div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#ID</th>
                                            <th> Name</th>     
                                            <th> Email</th> 
                                             <th> Photo</th> 
                        <th>Action</th>       
                                        </tr>
                                    </thead>
                                    <tbody>
                 <?php foreach($users as $user): ?>           
                     <tr class="odd gradeX">
                                            <td><?php echo e($user->user_id); ?></td>
                       <td><?php echo e($user->name); ?></td>  
                             <td><?php echo e($user->email); ?></td>  
<td><image  height="100px" width="100px" src="/uploads/<?php echo e($user->photo); ?>"/></td>  
                                            <td>
                 <td><a href = 'edit/<?php echo e($user->user_id); ?>'>Edit</a></td>
                <td><a href = 'delete/<?php echo e($user->user_id); ?>'>Delete</a></td>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <td><a href = 'view/<?php echo e($user->user_id); ?>'>View</a></td>
                        </td>
                                        </tr>
             <?php endforeach; ?>                                
                                    </tbody>
                                </table>
                               
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 