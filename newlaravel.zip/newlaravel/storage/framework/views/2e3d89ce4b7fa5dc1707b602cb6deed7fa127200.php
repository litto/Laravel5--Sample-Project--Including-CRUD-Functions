

<?php echo HTML::script('js/bower_components/jquery/dist/jquery.min.js'); ?>

<?php echo HTML::script('js/bower_components/bootstrap/dist/js/bootstrap.min.js'); ?>

<?php echo HTML::script('js/bower_components/metisMenu/dist/metisMenu.min.js'); ?>

<?php echo HTML::script('js/bower_components/datatables/media/js/jquery.dataTables.min.js'); ?>

<?php echo HTML::script('js/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js'); ?>

<?php echo HTML::script('js/dist/js/sb-admin-2.js'); ?>

<?php echo HTML::script('js/bower_components/bootstrap/dist/js/bootbox.min.js'); ?>

<?php echo HTML::script('js/select2.js'); ?>

<?php echo HTML::script('js/managepaintersPoints.js'); ?>

<?php echo HTML::script('js/managepainterPointDeduction.js'); ?>

<?php echo HTML::script('js/bootstrap-datepicker.js'); ?>

<!-- footer -->
