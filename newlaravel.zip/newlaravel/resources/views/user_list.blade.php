@include('header') 

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">User List</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          Listing All 
                        </div>
             <span class="msg">             

                </span>
            <div id="showMsg"></div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#ID</th>
                                            <th> Name</th>     
                                            <th> Email</th> 
                                             <th> Photo</th> 
                        <th>Action</th>       
                                        </tr>
                                    </thead>
                                    <tbody>
                 @foreach ($users as $user)           
                     <tr class="odd gradeX">
                                            <td>{{ $user->user_id }}</td>
                       <td>{{ $user->name }}</td>  
                             <td>{{ $user->email }}</td>  
<td><image  height="100px" width="100px" src="/uploads/{{ $user->photo }}"/></td>  
                                            <td>
                 <td><a href = 'edit/{{ $user->user_id }}'>Edit</a></td>
                <td><a href = 'delete/{{ $user->user_id }}'>Delete</a></td>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <td><a href = 'view/{{ $user->user_id }}'>View</a></td>
                        </td>
                                        </tr>
             @endforeach                                
                                    </tbody>
                                </table>
                               
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
@include('footer') 