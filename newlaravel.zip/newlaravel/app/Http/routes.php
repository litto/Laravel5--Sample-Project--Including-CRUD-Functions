<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/','AdminController@index');
Route::get('/index', array('as' => 'index', 'uses' => 'AdminController@index'));
Route::get('/home', array('as' => 'home', 'uses' => 'AdminController@home'));
Route::get('/logout', array('as' => 'logout', 'uses' => 'AdminController@logout'));
Route::post('loginsubmit','AdminController@loginsubmit');
Route::get('/list', array('as' => 'list', 'uses' => 'UserController@index'));
Route::get('/add', array('as' => 'add', 'uses' => 'UserController@create'));
Route::get('edit/{id}','UserController@edit');
Route::post('createsubmit','UserController@createsubmit');
Route::post('editsubmit/{id}','UserController@editsubmit');
Route::get('view/{id}','UserController@view');
Route::get('delete/{id}','UserController@delete');