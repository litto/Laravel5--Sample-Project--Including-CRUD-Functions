<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserController extends Controller {
   public function index(){
     $users = DB::table('cms_userauth')->get();
      return view('user_list',['users'=>$users]);
   }


      public function create(){
      return view('user_create');
      
      }

         public function createsubmit(Request $request){

      $name = $request->input('name');
        $email = $request->input('email');
        $file = $request->file('userfile');
      $destinationPath = 'uploads';
      $file->move($destinationPath,$file->getClientOriginalName());
     $imagename= $file->getClientOriginalName();
if($imagename==''){
	$imagename='user.png';
}
     // DB::insert('insert into cms_userauth (name),(email),(photo) values(?,?,?)',[$name],[$email],[$imagename]);

      DB::table('cms_userauth')->insert(
    array('name' =>$name, 'email' => $email,'photo'=>$imagename,'status'=>1)
);

      echo "Record inserted successfully.<br/>";
      return redirect('list');
   }


   public function edit(Request $request,$id) {
 // $users = DB::select('select * from cms_userauth where id = ?',[$id]);

$users = DB::table('cms_userauth')->where('user_id', '=', $id)->get();

      return view('user_edit',['users'=>$users]);
   }



         public function editsubmit(Request $request){

      $name = $request->input('name');
        $email = $request->input('email');
        $id= $request->input('id');
        $file = $request->file('userfile');

      $destinationPath = 'uploads';
      $file->move($destinationPath,$file->getClientOriginalName());
     $imagename= $file->getClientOriginalName();
if($imagename!=''){
	DB::table('cms_userauth')->where('user_id',$id)
            ->update(array('name' =>$name, 'email' => $email,'photo'=>$imagename));
}else{

DB::table('cms_userauth')->where('user_id',$id)->update(array('name' =>$name, 'email' => $email));
}
     // DB::insert('insert into cms_userauth (name),(email),(photo) values(?,?,?)',[$name],[$email],[$imagename]);
      echo "Record edited successfully.<br/>";
      return redirect('list');
   }



   public function view(Request $request,$id) {
 // $users = DB::select('select * from cms_userauth where id = ?',[$id]);

$users = DB::table('cms_userauth')->where('user_id', '=', $id)->get();

      return view('user_view',['users'=>$users]);
   }

   public function delete(Request $request,$id) {
 // $users = DB::select('select * from cms_userauth where id = ?',[$id]);

DB::table('cms_userauth')->where('user_id', '=', $id)->delete();

         echo "Record deleted successfully.<br/>";
      return redirect('list');
   }





}


