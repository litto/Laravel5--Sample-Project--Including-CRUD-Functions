<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class AdminController extends Controller {
   public function index(){
      return view('admin_login');
   }




         public function loginsubmit(Request $request){

       $email = $request->input('email');
        $password = $request->input('password');


$users = DB::table('cms_admin')->where('username', '=', $email)->get();
if($users[0]->password==$password){

$request->session()->put('loginadminname', $users[0]->username);
$request->session()->put('loginadminemail', $users[0]->email);
$request->session()->put('loginadmin', $users[0]->auth_id);
return redirect('home');

}else{
	  echo "Wrong Username & Password.<br/>";
      return redirect('index');
}

}


   public function home(Request $request){

$data = $request->session()->all();

   	if ($data['loginadmin']==1 ) {
   return view('admin_home');
}else{
	 return redirect('index');
}
// return view('admin_home');
     
   }



   public function logout(Request $request){

$request->session()->flush();
	 return redirect('index');

   }





}

  ?> 