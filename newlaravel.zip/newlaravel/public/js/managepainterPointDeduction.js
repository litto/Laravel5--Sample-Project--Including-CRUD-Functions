$(document).ajaxStart(function(){
    $("#waitQuantity").css("display", "block");
});
$(document).ajaxComplete(function(){
    $("#waitQuantity").css("display", "none");
});

$(document).ajaxStart(function(){
    $("#waitpoint").css("display", "block");
});
$(document).ajaxComplete(function(){
    $("#waitpoint").css("display", "none");
});


$(document).ajaxStart(function(){
    $("#waitproductPoint").css("display", "block");
});
$(document).ajaxComplete(function(){
    $("#waitproductPoint").css("display", "none");
});


$('.DeductPoint').click(function(){

var painterid=$(this).data('id');
var first_name= $(this).data('first_name');
$('#painterName').html(first_name);


var flag = 1;
//$('#deductquantity').css('');
$( "#deductquantity" ).prop( "disabled", true );
$.ajax({
global: false,
method:'get',
data:{painterid:painterid,flag:flag},
url:'getPainterPurchaseDetail.php'
}).done(function(data){
$('#ProductList1').hide();
$('#ProductList').html(data);
});



});


function getProductPoint(val){
var flag = 2;
var qvalue	=	$('#deductquantity').val();

if(qvalue == ''){
$('#deductquantityDiv').addClass('has-error');
$('#deductedTotal').val('');
}else{
$('#deductquantityDiv').removeClass('has-error');
}

if(val != ''){
$('#ProductList').removeClass('has-error');
$( "#deductquantity" ).prop( "disabled", false );
$.ajax({
method:'get',
data:{purchaseid:val,flag:flag},
url:'getPainterPurchaseDetail.php'
}).done(function(data){
var newdata=JSON.parse(data);
$('#productPoint').val(newdata.point);
$('#productQuantity').val(newdata.quantity);
$('#ProducttotalPoint').val(newdata.total);


if(val != '' && qvalue != ''){
var pointValue = newdata.quantity;
//$('#productQuantity').val();
if(parseInt(pointValue) < parseInt(qvalue) ){
$('#deductquantity').val('');
$('#deductedTotal').val('');
$('#MsgBox1').html('<div class="alert alert-warning">Quantity should be less than or equal to the Quantity Purchased!..</div>')
$('#deductquantityDiv').addClass('has-error');
}else{
$('#MsgBox1').html('');
$('#deductquantityDiv').removeClass('has-error');
//calculate total point on the basis of quantity
var perlitre		=	$('#productPoint').val();
var totValue		=	$('#ProducttotalPoint').val();
var calculatedValue	=	qvalue * perlitre;
var newTotal		=	totValue - calculatedValue;
$('#deductedTotal').val(calculatedValue);
}
}
});
}else{
$( "#deductquantity" ).val('');
$( "#deductquantity" ).prop( "disabled", true );
$('#ProductList').addClass('has-error');
}
}


$("#deductquantity").keyup(function(){
delay(function(){      
var pvalue =  $('select#deductProduct').val();
var qvalue =  $('#deductquantity').val();


if(pvalue == ''){
$('#ProductList').addClass('has-error');
}else{
$('#ProductList').removeClass('has-error');
}
if(qvalue == ''){
$('#deductquantityDiv').addClass('has-error');
$('#deductedTotal').val('');
}else{
$('#deductquantityDiv').removeClass('has-error');
}
if(pvalue != '' && qvalue != ''){
var pointValue = $('#productQuantity').val();

if(parseInt(pointValue) < parseInt(qvalue) ){

$('#deductquantity').val('');
$('#deductedTotal').val('');
$('#MsgBox1').html('<div class="alert alert-warning">Quantity should be less than or equal to the Quantity Purchased!..</div>')
$('#deductquantityDiv').addClass('has-error');

}else{

$('#MsgBox1').html('');
$('#deductquantityDiv').removeClass('has-error');
//calculated the points based on quantity 
var perlitre		=	$('#productPoint').val();
var totValue		=	$('#ProducttotalPoint').val();
var calculatedValue	=	qvalue * perlitre;
var newTotal		=	totValue - calculatedValue;
$('#deductedTotal').val(calculatedValue);

}
}

}, 300);
});

$('#DeductSave').click(function(){
var purchaseid	=	$('select#deductProduct').val();
var quantity	=	$('#deductquantity').val();
var perlitre	=	$('#productPoint').val();
var flag = 3;

if(purchaseid != '' &&  quantity != '' && perlitre != ''){
$('#ProductList').removeClass('has-error');
$('#deductquantityDiv').removeClass('has-error');

$.ajax({
global:false,
method:'GET',
data: {purchaseid:purchaseid,quantity:quantity,perlitre:perlitre,flag:flag},
url:'getPainterPurchaseDetail.php',
}).done(function(data){
var newdata=JSON.parse(data);
$('#MsgBox1').html(newdata.msg);
var painterid  = 	newdata.painterid;

$('td#TotPoint'+painterid+'').html(newdata.painterTotal);
$('#DeductSave').attr('disabled',true);

var perlitre		=	$('#productPoint').val();
var totValue		=	$('#ProducttotalPoint').val();
var calculatedValue	=	quantity * perlitre;
var newTotal		=	totValue - calculatedValue;
$('#PointAftrDeduction').val(newTotal);
$('#purchasededuction').show();
$('#purchasededuction').addClass('has-success');

$('select#deductProduct').attr('disabled',true);
$('#deductquantity').attr('disabled',true);


});
}else{
$('#ProductList').addClass('has-error');
$('#deductquantityDiv').addClass('has-error');
return false;
}
return false;
});

function resetAllformdata(){
$("#deductPainterPointForm")[0].reset();
$('#purchasededuction').hide();
$('#DeductSave').attr('disabled',false);
$('#MsgBox1').html('');
}

//$( 'td#TotPoint'+painterid+'' ).load( 'viewPainters.php td#TotPoint'+painterid+'' );

/*
$('.DeductPoint').click(function(){
var painterid=$(this).data('id');

$('#deductpoint').val('');
$('#DeductSave').attr('disabled',false);
$('#MsgBox1').html('');



if(painterid != ''){
var flag = 1;
$.ajax({
type:'GET',
data:{pid:painterid,flag:flag},
url:'showCurrentPoints.php'
}).done(function(data){
$('#totpoint').val(data);
});
}







$("#deductpoint").unbind().keyup(function(){

var Dpoint = $('#deductpoint').val();
if(Dpoint !='' ){
var flag = 2;
$.ajax({
type:'GET',
data:{pid:painterid,Dpoint:Dpoint,flag:flag},
url:'showCurrentPoints.php'
}).done(function(data){
$('#totpoint').val(data);
$('#afterdeduction').html('Points After Deduction');
});
}else{
var flag = 1;
$.ajax({
type:'GET',
data:{pid:painterid,flag:flag},
url:'showCurrentPoints.php'
}).done(function(data){
$('#totpoint').val(data);
$('#afterdeduction').html('Total Points');
});
}
});





 
$('#DeductSave').unbind().click(function(){
var v = $('#deductpoint').val();

if(v == ''){
$('#deductPointDiv').addClass('has-error');
return false;
}else{
$('#deductPointDiv').removeClass('has-error');
$.ajax({
global: false,
type:'GET',
data:{pid:painterid,val:v},
url:'DeductPoint.php'
}).done(function(data){
var newdata=JSON.parse(data);
$('#afterdeduction').html('Points After Deduction');
$('#totpoint').val(newdata[0]);
$('#MsgBox1').html(newdata[1]);
$('#DeductSave').attr('disabled',true);
$('td#TotPoint'+painterid+'').html(newdata[0]);
});
}
return false;
});


});
//end of deduction section

*/


